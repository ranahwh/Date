import 'package:agora_uikit/agora_uikit.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:orange_ui/utils/const_res.dart';

class VideoCallScreen extends StatefulWidget {
  const VideoCallScreen({Key? key, required this.roomId}) : super(key: key);
  final String roomId;

  @override
  State<VideoCallScreen> createState() => _VideoCallScreenState();
}

class _VideoCallScreenState extends State<VideoCallScreen> {
  late AgoraClient client;

  @override
  void initState() {
    super.initState();
    initAgora();
  }

  void initAgora() async {
    client = AgoraClient(
      agoraConnectionData: AgoraConnectionData(
        appId: ConstRes.agoraAppId,
        channelName: widget.roomId,
      ),
      enabledPermission: [
        Permission.camera,
        Permission.microphone,
      ],
    );
    await client.initialize();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              AgoraVideoViewer(client: client),
              AgoraVideoButtons(
                client: client,
                onDisconnect: () {
                  Get.back();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
