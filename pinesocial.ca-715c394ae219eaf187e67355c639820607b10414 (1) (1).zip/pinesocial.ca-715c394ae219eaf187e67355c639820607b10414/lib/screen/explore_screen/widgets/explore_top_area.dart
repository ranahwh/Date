import 'dart:async';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:orange_ui/utils/asset_res.dart';
import 'package:orange_ui/utils/color_res.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:stacked/stacked.dart';

import '../../notification_screen/notification_screen_view_model.dart';
import '../explore_screen_view_model.dart';

class ExploreTopArea extends StatefulWidget {
  final VoidCallback onNotificationTap;
  final VoidCallback onTitleTap;
  final VoidCallback onSearchTap;
  final ExploreScreenViewModel model;

  const ExploreTopArea({
    Key? key,
    required this.onNotificationTap,
    required this.onSearchTap,
    required this.onTitleTap,
    required this.model,
  }) : super(key: key);

  @override
  State<ExploreTopArea> createState() => _ExploreTopAreaState();
}

class _ExploreTopAreaState extends State<ExploreTopArea> {
  Future<int?> getNotificationCount() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    return sharedPreferences.getInt("notification_count");
  }

  late StreamSubscription<RemoteMessage> streamSubscription;
  int refresh = 0;

  @override
  void initState() {
    super.initState();
    streamSubscription = FirebaseMessaging.onMessage.listen((v) {
      refresh++;
      setState(() {});
    });
  }

  @override
  void dispose() {
    super.dispose();
    streamSubscription.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      key: ValueKey(refresh),
      padding: const EdgeInsets.only(left: 20, right: 20, top: 20),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ViewModelBuilder<NotificationScreenViewModel>.reactive(
                onViewModelReady: (model) {
                  model.init();
                },
                viewModelBuilder: () => NotificationScreenViewModel(),
                builder: (context, model, child) {
                  return FutureBuilder(
                    future: getNotificationCount(),
                    builder: (BuildContext context, AsyncSnapshot<int?> snapshot) {
                      bool showDot = false;
                      if (model.isUserLoading == false) {
                        final length = (model.userNotification ?? []).length;
                        if (snapshot.data != null) {
                          showDot = length > snapshot.data!;
                        }
                      }
                      return InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: widget.model.onNotificationTap,
                        child: Stack(
                          children: [
                            Container(
                              height: 37,
                              width: 37,
                              decoration:
                                  BoxDecoration(color: ColorRes.orange3.withOpacity(0.1), shape: BoxShape.circle),
                              child: Center(
                                child: Image.asset(
                                  AssetRes.bell,
                                  height: 20,
                                  width: 20,
                                ),
                              ),
                            ),
                            if (showDot)
                              Positioned(
                                  top: 0,
                                  right: 0,
                                  child: Container(
                                    decoration: const BoxDecoration(color: ColorRes.orange, shape: BoxShape.circle),
                                    width: 10,
                                    height: 10,
                                  ))
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: widget.onSearchTap,
                child: Container(
                  height: 37,
                  width: 37,
                  decoration: BoxDecoration(color: ColorRes.orange3.withOpacity(0.1), shape: BoxShape.circle),
                  child: Center(
                    child: Image.asset(
                      AssetRes.search,
                      height: 20,
                      width: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
          InkWell(
            onTap: widget.onTitleTap,
            child: Image.asset(
              AssetRes.themeLabel,
              height: 28,
              width: 94,
            ),
          ),
        ],
      ),
    );
  }
}
