import 'dart:developer';
import 'dart:ui';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_swiper_null_safety/flutter_swiper_null_safety.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:orange_ui/common/widgets/full_image_view_shimmer.dart';
import 'package:orange_ui/common/widgets/live_icon.dart';
import 'package:orange_ui/common/widgets/profile_detail_card.dart';
import 'package:orange_ui/common/widgets/social_icon.dart';
import 'package:orange_ui/common/widgets/top_story_line.dart';
import 'package:orange_ui/generated/assets.dart';
import 'package:orange_ui/generated/l10n.dart';
import 'package:orange_ui/model/user/registration_user.dart';
import 'package:orange_ui/utils/asset_res.dart';
import 'package:orange_ui/utils/color_res.dart';
import 'package:orange_ui/utils/const_res.dart';
import 'package:orange_ui/utils/font_res.dart';

import '../../../api_provider/api_provider.dart';
import '../../../common/widgets/snack_bar_widget.dart';
import '../../../service/pref_service.dart';
import '../dialogs/show_mutual_like_dialog.dart';
import '../explore_screen_view_model.dart';

class FullImageView extends StatefulWidget {
  final ExploreScreenViewModel exploreScreenViewModel;
  final List<RegistrationUserData>? userData;
  final VoidCallback onLiveBtnTap;
  final VoidCallback onImageTap;
  final VoidCallback onInstagramTap;
  final VoidCallback onFacebookTap;
  final VoidCallback onYoutubeTap;
  final bool isLoading;
  final SwiperController userController;
  final Function(int index) onIndexChange;
  final bool Function(String? value) isSocialBtnVisible;

  const FullImageView(
      {Key? key,
      this.userData,
      required this.onLiveBtnTap,
      required this.onImageTap,
      required this.onInstagramTap,
      required this.onFacebookTap,
      required this.onYoutubeTap,
      required this.isLoading,
      required this.userController,
      required this.onIndexChange,
      required this.isSocialBtnVisible,
      required this.exploreScreenViewModel})
      : super(key: key);

  @override
  State<FullImageView> createState() => _FullImageViewState();
}

class _FullImageViewState extends State<FullImageView> {
  updateLike(dynamic id) {
    log("Updating Like.....    $id");
    ApiProvider().updateLikedProfile(id).then((value) {
      ApiProvider().notifyLikeUser(
        userId: id,
        type: 1,
      );
    });
  }

  CardSwiperDirection? currentDirection;

  RegistrationUserData? users;
  int previousIndexSelected = 0;

  Future showMutualLikeUI(RegistrationUserData registrationData) async {
    if (widget.exploreScreenViewModel.users?.isBlock == 1) {
      SnackBarWidget().snackBarWidget(S.current.userBlock);
      return;
    }
    await showDialog(
        context: context,
        builder: (c) {
          return ShowMutualLikeDialog(
            registrationData: registrationData,
            myUser: users!,
            // exploreScreenViewModel: widget.exploreScreenViewModel,
          );
        });
  }

  @override
  void initState() {
    super.initState();
    ApiProvider().getProfile(userID: PrefService.userId).then((value) async {
      users = value?.data;
      await PrefService.saveUser(value?.data);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (widget.isLoading) {
      return const FullImageViewShimmer();
    } else {
      return Expanded(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 14),
          child: AspectRatio(
            aspectRatio: 1 / 1.20,
            child: CardSwiper(
              // controller: userController,
              initialIndex: 0,
              threshold: 60,
              // duration: 500,
              onSwipe: (
                int previousIndex,
                int? currentIndex,
                CardSwiperDirection direction,
              ) async {
                // return false;
                if (direction == CardSwiperDirection.bottom || direction == CardSwiperDirection.top) {
                  // widget.exploreScreenViewModel.onEyeButtonTap();
                  return false;
                }
                if (direction == CardSwiperDirection.right) {
                  updateLike(widget.userData?[previousIndex].id);
                  final item = widget.userData?[previousIndex].likedprofile;
                  if (item != null &&
                      item.toString().split(",").contains(widget.exploreScreenViewModel.users?.id.toString())) {
                    await showMutualLikeUI(widget.userData![previousIndex]);
                  }
                  previousIndexSelected = currentIndex ?? -1;
                  // await Future.delayed(GetNumUtils(10).seconds);
                  return true;
                }
                previousIndexSelected = currentIndex ?? -1;
                // print(direction.name);
                // onIndexChange(currentIndex!);
                return true;
              },
              onSwipeDirectionChange: (
                CardSwiperDirection horizontalDirection,
                CardSwiperDirection verticalDirection,
              ) {
                if (kDebugMode) {
                  print("horizontalDirection.....     $horizontalDirection");
                }

                if (currentDirection != horizontalDirection) {
                  currentDirection = horizontalDirection;
                  setState(() {});
                }
              },
              allowedSwipeDirection: const AllowedSwipeDirection.only(left: true, right: true),
              backCardOffset: Offset.zero,
              cardsCount: widget.userData?.length ?? 0,
              cardBuilder: (BuildContext context, int currentProfileIndex, int horizontalOffsetPercentage,
                  int verticalOffsetPercentage) {
                List<Images>? imagesProfile = widget.userData?[currentProfileIndex].images;
                final PageController pageController = PageController();
                return Stack(
                  children: [
                    Positioned.fill(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          color: Colors.white,
                          child: Container(
                            color: Colors.lightBlue.shade50,
                          ),
                        ),
                      ),
                    ),
                    imagesProfile == null || imagesProfile.isEmpty
                        ? Container(
                            width: double.infinity,
                            height: Get.height,
                            decoration: BoxDecoration(
                              color: ColorRes.lightGrey,
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Image.asset(AssetRes.imageWarning),
                          )
                        : ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: PageView.builder(
                              controller: pageController,
                              itemCount: imagesProfile.length,
                              physics: const NeverScrollableScrollPhysics(),
                              itemBuilder: (context, currentImageIndex) {
                                final image = imagesProfile[currentImageIndex].image ?? "";
                                return Stack(
                                  children: [
                                    FadeInImage(
                                      placeholder: const AssetImage(AssetRes.placeholder),
                                      image: NetworkImage(
                                        '${ConstRes.aImageBaseUrl}$image',
                                      ),
                                      key: ValueKey('${ConstRes.aImageBaseUrl}$image'),
                                      fit: BoxFit.cover,
                                      width: double.infinity,
                                      height: double.infinity,
                                      filterQuality: FilterQuality.medium,
                                      imageErrorBuilder: (context, error, stackTrace) {
                                        return Container(
                                          color: ColorRes.grey13,
                                          child: Image.asset(
                                            AssetRes.themeLabel,
                                            width: Get.width,
                                            height: Get.height,
                                          ),
                                        );
                                      },
                                    ),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              if (currentImageIndex == 0) {
                                                return;
                                              }
                                              pageController.previousPage(
                                                  duration: const Duration(milliseconds: 500), curve: Curves.linear);
                                            },
                                            child: Container(
                                              height: Get.height - 256,
                                              color: ColorRes.transparent,
                                            ),
                                          ),
                                        ),
                                        Expanded(
                                          child: InkWell(
                                            onTap: () {
                                              if (imagesProfile.length - 1 == currentImageIndex) {
                                                return;
                                              }
                                              pageController.nextPage(
                                                  duration: const Duration(milliseconds: 500), curve: Curves.linear);
                                            },
                                            child: Container(
                                              height: Get.height - 256,
                                              color: ColorRes.transparent,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                    Column(
                      children: [
                        const SizedBox(height: 14),
                        TopStoryLine(
                          pageController: pageController,
                          images: imagesProfile ?? [],
                        ),
                        const Spacer(),
                        Padding(
                          padding: const EdgeInsets.only(left: 9),
                          child: Row(
                            children: [
                              SocialIcon(
                                  icon: AssetRes.instagramLogo,
                                  size: 15,
                                  onSocialIconTap: widget.onInstagramTap,
                                  isVisible:
                                      widget.isSocialBtnVisible(widget.userData?[currentProfileIndex].instagram)),
                              SocialIcon(
                                  icon: AssetRes.facebookLogo,
                                  size: 21.0,
                                  onSocialIconTap: widget.onFacebookTap,
                                  isVisible: widget.isSocialBtnVisible(widget.userData?[currentProfileIndex].facebook)),
                              SocialIcon(
                                  icon: AssetRes.youtubeLogo,
                                  size: 20.16,
                                  onSocialIconTap: widget.onYoutubeTap,
                                  isVisible: widget.isSocialBtnVisible(widget.userData?[currentProfileIndex].youtube)),
                              const Spacer(),
                              Visibility(
                                visible: widget.userData?[currentProfileIndex].isLiveNow == 1 ? true : false,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(20),
                                  child: BackdropFilter(
                                    filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                    child: InkWell(
                                      onTap: widget.onLiveBtnTap,
                                      child: Container(
                                        height: 35,
                                        width: 113,
                                        padding: const EdgeInsets.all(4),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(40),
                                          color: ColorRes.black.withOpacity(0.33),
                                        ),
                                        child: Row(
                                          children: [
                                            const LiveIcon(),
                                            Text(
                                              " ${S.current.liveCap}",
                                              style: const TextStyle(
                                                color: ColorRes.white,
                                                fontSize: 12,
                                              ),
                                            ),
                                            Text(
                                              " ${S.current.nowCap}",
                                              style: const TextStyle(
                                                color: ColorRes.white,
                                                fontFamily: FontRes.bold,
                                                fontSize: 12,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                            ],
                          ),
                        ),
                        ProfileDetailCard(
                          userData: widget.userData?[currentProfileIndex],
                          onImageTap: widget.onImageTap,
                          viewProfile: Visibility(
                            visible: PrefService.settingData?.appdata?.isDating == 0 ? false : true,
                            child: InkWell(
                              onTap: () {
                                widget.exploreScreenViewModel.onEyeButtonTap(widget.userData?[currentProfileIndex]);
                              },
                              borderRadius: BorderRadius.circular(10),
                              child: Center(
                                child: Image.asset(
                                  AssetRes.eye,
                                  color: Colors.white,
                                  height: 22,
                                  width: 30,
                                ),
                              ),
                            ),
                          ),
                        )
                      ],
                    ),
                    if (previousIndexSelected == currentProfileIndex && currentDirection == CardSwiperDirection.right)
                      Positioned(
                          top: 0,
                          left: -context.width * .38,
                          // bottom: 0,
                          // right: 0,
                          child: Container(
                            // height: context.height*.5,
                            width: context.width * 1.1,
                            alignment: Alignment.centerLeft,
                            child: ColorFiltered(
                              colorFilter: const ColorFilter.mode(
                                Colors.pink,
                                BlendMode.modulate,
                              ),
                              child: Lottie.asset(
                                "assets/icons/love_animation.json",
                                filterQuality: FilterQuality.high,
                              ),
                            ),
                          ).animate().fade(duration: GetNumUtils(500).milliseconds)),
                    if (previousIndexSelected == currentProfileIndex && currentDirection == CardSwiperDirection.left)
                      Positioned(
                          top: 0,
                          right: 0,
                          // bottom: 0,
                          // right: 0,
                          child: Container(
                            // height: context.height*.5,
                            width: context.width * .36,
                            alignment: Alignment.centerLeft,
                            // height: ,
                            child: ColorFiltered(
                              colorFilter: const ColorFilter.mode(
                                Colors.pink,
                                BlendMode.modulate,
                              ),
                              child: Image.asset(Assets.iconsNope),
                            ),
                          )
                              .animate()
                              .fade(duration: GetNumUtils(500).milliseconds)
                              .scale(duration: GetNumUtils(100).milliseconds)),
                  ],
                );
              },
              // physics: const NeverScrollableScrollPhysics(),
              // onIndexChanged: onIndexChange,
              // itemBuilder: (context, currentProfileIndex) {
              //   List<Images>? imagesProfile = imagesProfile;
              //   final PageController pageController = PageController();
              //   return Stack(
              //     children: [
              //       imagesProfile == null || imagesProfile.isEmpty
              //           ? Container(
              //               width: double.infinity,
              //               height: Get.height,
              //               decoration: BoxDecoration(
              //                 color: ColorRes.lightGrey,
              //                 borderRadius: BorderRadius.circular(20),
              //               ),
              //               child: Image.asset(AssetRes.imageWarning),
              //             )
              //           : ClipRRect(
              //               borderRadius: BorderRadius.circular(20),
              //               child: PageView.builder(
              //                 controller: pageController,
              //                 itemCount: imagesProfile?.length,
              //                 physics: const NeverScrollableScrollPhysics(),
              //                 itemBuilder: (context, currentImageIndex) {
              //                   return Stack(
              //                     children: [
              //                       FadeInImage(
              //                         placeholder: const AssetImage(AssetRes.placeholder),
              //                         image: NetworkImage(
              //                           '${ConstRes.aImageBaseUrl}${imagesProfile[currentImageIndex].image}',
              //                         ),
              //                         fit: BoxFit.cover,
              //                         width: double.infinity,
              //                         height: double.infinity,
              //                         filterQuality: FilterQuality.medium,
              //                         imageErrorBuilder: (context, error, stackTrace) {
              //                           return Container(
              //                             color: ColorRes.grey13,
              //                             child: Image.asset(
              //                               AssetRes.themeLabel,
              //                               width: Get.width,
              //                               height: Get.height,
              //                             ),
              //                           );
              //                         },
              //                       ),
              //                       Row(
              //                         children: [
              //                           Expanded(
              //                             child: InkWell(
              //                               onTap: () {
              //                                 if (currentImageIndex == 0) {
              //                                   return;
              //                                 }
              //                                 pageController.previousPage(
              //                                     duration: const Duration(milliseconds: 500), curve: Curves.linear);
              //                               },
              //                               child: Container(
              //                                 height: Get.height - 256,
              //                                 color: ColorRes.transparent,
              //                               ),
              //                             ),
              //                           ),
              //                           Expanded(
              //                             child: InkWell(
              //                               onTap: () {
              //                                 if (imagesProfile.length - 1 == currentImageIndex) {
              //                                   return;
              //                                 }
              //                                 pageController.nextPage(
              //                                     duration: const Duration(milliseconds: 500), curve: Curves.linear);
              //                               },
              //                               child: Container(
              //                                 height: Get.height - 256,
              //                                 color: ColorRes.transparent,
              //                               ),
              //                             ),
              //                           ),
              //                         ],
              //                       )
              //                     ],
              //                   );
              //                 },
              //               ),
              //             ),
              //       Column(
              //         children: [
              //           const SizedBox(height: 14),
              //           TopStoryLine(
              //             pageController: pageController,
              //             images: imagesProfile ?? [],
              //           ),
              //           const Spacer(),
              //           Padding(
              //             padding: const EdgeInsets.only(left: 9),
              //             child: Row(
              //               children: [
              //                 SocialIcon(
              //                     icon: AssetRes.instagramLogo,
              //                     size: 15,
              //                     onSocialIconTap: onInstagramTap,
              //                     isVisible: isSocialBtnVisible(userData?[currentProfileIndex].instagram)),
              //                 SocialIcon(
              //                     icon: AssetRes.facebookLogo,
              //                     size: 21.0,
              //                     onSocialIconTap: onFacebookTap,
              //                     isVisible: isSocialBtnVisible(userData?[currentProfileIndex].facebook)),
              //                 SocialIcon(
              //                     icon: AssetRes.youtubeLogo,
              //                     size: 20.16,
              //                     onSocialIconTap: onYoutubeTap,
              //                     isVisible: isSocialBtnVisible(userData?[currentProfileIndex].youtube)),
              //                 const Spacer(),
              //                 Visibility(
              //                   visible: userData?[currentProfileIndex].isLiveNow == 1 ? true : false,
              //                   child: ClipRRect(
              //                     borderRadius: BorderRadius.circular(20),
              //                     child: BackdropFilter(
              //                       filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
              //                       child: InkWell(
              //                         onTap: onLiveBtnTap,
              //                         child: Container(
              //                           height: 35,
              //                           width: 113,
              //                           padding: const EdgeInsets.all(4),
              //                           decoration: BoxDecoration(
              //                             borderRadius: BorderRadius.circular(40),
              //                             color: ColorRes.black.withOpacity(0.33),
              //                           ),
              //                           child: Row(
              //                             children: [
              //                               const LiveIcon(),
              //                               Text(
              //                                 " ${S.current.liveCap}",
              //                                 style: const TextStyle(
              //                                   color: ColorRes.white,
              //                                   fontSize: 12,
              //                                 ),
              //                               ),
              //                               Text(
              //                                 " ${S.current.nowCap}",
              //                                 style: const TextStyle(
              //                                   color: ColorRes.white,
              //                                   fontFamily: FontRes.bold,
              //                                   fontSize: 12,
              //                                 ),
              //                               ),
              //                             ],
              //                           ),
              //                         ),
              //                       ),
              //                     ),
              //                   ),
              //                 ),
              //                 const SizedBox(width: 10),
              //               ],
              //             ),
              //           ),
              //           ProfileDetailCard(
              //             userData: userData?[currentProfileIndex],
              //             onImageTap: onImageTap,
              //           )
              //         ],
              //       ),
              //     ],
              //   );
              // },
            ),
          ),
        ),
      );
    }
  }
}
