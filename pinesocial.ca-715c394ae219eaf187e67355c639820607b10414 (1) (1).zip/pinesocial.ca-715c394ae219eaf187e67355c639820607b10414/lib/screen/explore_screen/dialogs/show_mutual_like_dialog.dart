import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../common/widgets/common_fun.dart';
import '../../../model/chat_and_live_stream/chat.dart';
import '../../../model/user/registration_user.dart';
import '../../../service/pref_service.dart';
import '../../../utils/color_res.dart';
import '../../../utils/font_res.dart';
import '../../chat_screen/chat_screen.dart';

class ShowMutualLikeDialog extends StatefulWidget {
  const ShowMutualLikeDialog({Key? key, required this.registrationData, required this.myUser}) : super(key: key);
  final RegistrationUserData registrationData;
  final RegistrationUserData myUser;

  // final ExploreScreenViewModel exploreScreenViewModel;

  @override
  State<ShowMutualLikeDialog> createState() => _ShowMutualLikeDialogState();
}

class _ShowMutualLikeDialogState extends State<ShowMutualLikeDialog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      child: Container(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            const Text(
              'Congratulations!',
              style: TextStyle(
                fontSize: 32,
                fontWeight: FontWeight.bold,
                color: Colors.green,
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'You both likes each other\n${widget.registrationData.fullname}',
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w500,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 24),
            InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                Navigator.pop(context);
                PrefService.getUserData().then((value) {
                  ChatUser chatUser = ChatUser(
                    age: '${widget.registrationData.age ?? ''}',
                    city: widget.registrationData.live ?? '',
                    image: widget.registrationData.images == null || widget.registrationData.images!.isEmpty
                        ? ''
                        : widget.registrationData.images?[0].image,
                    userIdentity: widget.registrationData.identity,
                    userid: widget.registrationData.id,
                    isNewMsg: false,
                    isHost: widget.registrationData.isVerified == 2 ? true : false,
                    date: DateTime.now().millisecondsSinceEpoch.toDouble(),
                    username: widget.registrationData.fullname,
                  );
                  Conversation conversation = Conversation(
                    block: widget.myUser.blockedUsers?.contains('${widget.registrationData.id}') == true ? true : false,
                    blockFromOther:
                        widget.registrationData.blockedUsers?.contains('${widget.registrationData.id}') == true
                            ? true
                            : false,
                    conversationId:
                        CommonFun.getConversationID(myId: value?.id, otherUserId: widget.registrationData.id),
                    deletedId: '',
                    time: DateTime.now().millisecondsSinceEpoch.toDouble(),
                    isDeleted: false,
                    isMute: false,
                    lastMsg: '',
                    newMsg: '',
                    user: chatUser,
                  );
                  Get.to(() => ChatScreen(conversation: conversation));
                });
              },
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: ColorRes.red3,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.message,
                      color: Colors.white,
                      size: 20,
                    ),
                    Text(
                      "  Send Message",
                      style: TextStyle(
                        fontFamily: FontRes.bold,
                        color: Colors.white,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            InkWell(
              borderRadius: BorderRadius.circular(10),
              onTap: () {
                Navigator.pop(context);
                PrefService.getUserData().then((value) {
                  ChatUser chatUser = ChatUser(
                    age: '${widget.registrationData.age ?? ''}',
                    city: widget.registrationData.live ?? '',
                    image: widget.registrationData.images == null || widget.registrationData.images!.isEmpty
                        ? ''
                        : widget.registrationData.images?[0].image,
                    userIdentity: widget.registrationData.identity,
                    userid: widget.registrationData.id,
                    isNewMsg: false,
                    isHost: widget.registrationData.isVerified == 2 ? true : false,
                    date: DateTime.now().millisecondsSinceEpoch.toDouble(),
                    username: widget.registrationData.fullname,
                  );
                  Conversation conversation = Conversation(
                    block: widget.myUser.blockedUsers?.contains('${widget.registrationData.id}') == true ? true : false,
                    blockFromOther:
                        widget.registrationData.blockedUsers?.contains('${widget.registrationData.id}') == true
                            ? true
                            : false,
                    conversationId:
                        CommonFun.getConversationID(myId: value?.id, otherUserId: widget.registrationData.id),
                    deletedId: '',
                    time: DateTime.now().millisecondsSinceEpoch.toDouble(),
                    isDeleted: false,
                    isMute: false,
                    lastMsg: '',
                    newMsg: '',
                    user: chatUser,
                  );
                  Get.to(() => ChatScreen(conversation: conversation));
                });
              },
              child: Container(
                height: 50,
                decoration: BoxDecoration(
                  color: ColorRes.red3,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.video_call,
                      color: Colors.white,
                      size: 20,
                    ),
                    Text(
                      "  Start Video Call",
                      style: TextStyle(
                        fontFamily: FontRes.bold,
                        color: Colors.white,
                        letterSpacing: 0.8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

// class CelebrationContent extends StatelessWidget {
//   void _sendMessage() {
//     // Navigate to message screen or open chat
//     print('Send Message');
//   }
//
//   void _videoCall() {
//     // Navigate to video call screen or initiate video call
//     print('Start Video Call');
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.all(16.0),
//       child: Column(
//         mainAxisAlignment: MainAxisAlignment.center,
//         crossAxisAlignment: CrossAxisAlignment.center,
//         children: <Widget>[
//           Text(
//             'Congratulations!',
//             style: TextStyle(
//               fontSize: 32,
//               fontWeight: FontWeight.bold,
//               color: Colors.green,
//             ),
//           ),
//           SizedBox(height: 20),
//           Text(
//             'You both liked each other!',
//             style: TextStyle(
//               fontSize: 24,
//               color: Colors.black,
//             ),
//           ),
//           SizedBox(height: 50),
//           Image.asset('assets/celebration.png'), // Make sure you have an image asset
//           SizedBox(height: 50),
//           ElevatedButton.icon(
//             onPressed: _sendMessage,
//             icon: Icon(Icons.message),
//             label: Text('Send Message'),
//             style: ElevatedButton.styleFrom(
//               primary: Colors.blue,
//               onPrimary: Colors.white,
//               padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//               textStyle: TextStyle(fontSize: 18),
//             ),
//           ),
//           SizedBox(height: 20),
//           ElevatedButton.icon(
//             onPressed: _videoCall,
//             icon: Icon(Icons.video_call),
//             label: Text('Start Video Call'),
//             style: ElevatedButton.styleFrom(
//               primary: Colors.green,
//               onPrimary: Colors.white,
//               padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
//               textStyle: TextStyle(fontSize: 18),
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
