import 'dart:developer';
import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_card_swiper/flutter_card_swiper.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:orange_ui/common/widgets/live_icon.dart';
import 'package:orange_ui/common/widgets/profile_detail_card.dart';
import 'package:orange_ui/common/widgets/social_icon.dart';
import 'package:orange_ui/common/widgets/top_story_line.dart';
import 'package:orange_ui/generated/l10n.dart';
import 'package:orange_ui/model/user/registration_user.dart';
import 'package:orange_ui/screen/shimmer_screen/shimmer_screen.dart';
import 'package:orange_ui/utils/asset_res.dart';
import 'package:orange_ui/utils/color_res.dart';
import 'package:orange_ui/utils/const_res.dart';
import 'package:orange_ui/utils/firebase_res.dart';
import 'package:orange_ui/utils/font_res.dart';

import '../../../api_provider/api_provider.dart';
import '../../../common/widgets/snack_bar_widget.dart';
import '../../../generated/assets.dart';
import '../../../service/pref_service.dart';
import '../../explore_screen/dialogs/show_mutual_like_dialog.dart';
import '../randoms_search_screen_view_model.dart';

class ProfilePicArea extends StatefulWidget {
  final bool isLoading;
  final RegistrationUserData? userData;
  final PageController pageController;
  final VoidCallback onLeftBtnClick;
  final VoidCallback onRightBtnClick;
  final VoidCallback onInstagramTap;
  final VoidCallback onFacebookTap;
  final VoidCallback onYoutubeTap;
  final VoidCallback onLiveBtnTap;
  final VoidCallback onImageTap;
  final bool Function(String?) isSocialBtnVisible;
  final RandomsSearchScreenViewModel model;

  const ProfilePicArea(
      {Key? key,
      this.userData,
      required this.isLoading,
      required this.pageController,
      required this.onLeftBtnClick,
      required this.onRightBtnClick,
      required this.onFacebookTap,
      required this.onInstagramTap,
      required this.onYoutubeTap,
      required this.onLiveBtnTap,
      required this.onImageTap,
      required this.isSocialBtnVisible,
      required this.model})
      : super(key: key);

  @override
  State<ProfilePicArea> createState() => _ProfilePicAreaState();
}

class _ProfilePicAreaState extends State<ProfilePicArea> {
  CardSwiperDirection? currentDirection;

  int previousIndexSelected = 0;

  int cIndex = 0;

  updateLike(dynamic id) {
    log("Updating Like.....    $id");
    ApiProvider().updateLikedProfile(id).then((value) {
      ApiProvider().notifyLikeUser(
        userId: id,
        type: 1,
      );
    });
  }

  RegistrationUserData? users;

  getData() {
    ApiProvider().getProfile(userID: PrefService.userId).then((value) async {
      users = value?.data;
      await PrefService.saveUser(value?.data);
    });
  }

  @override
  void didUpdateWidget(covariant ProfilePicArea oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isLoading != oldWidget.isLoading) {
      previousIndexSelected = 0;
      cIndex = 0;
      log("Index Updated....   ${cIndex}");
    }
  }

  Future showMutualLikeUI(RegistrationUserData registrationData) async {
    if (users?.isBlock == 1) {
      SnackBarWidget().snackBarWidget(S.current.userBlock);
      return;
    }
    if (users == null) return;
    await showDialog(
        context: context,
        builder: (c) {
          return ShowMutualLikeDialog(
            registrationData: registrationData,
            myUser: users!,
            // exploreScreenViewModel: widget.exploreScreenViewModel,
          );
        });
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return widget.isLoading
        ? Container(
            width: Get.width,
            height: Get.height / 2,
            decoration: const BoxDecoration(
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage(AssetRes.worldMap),
              ),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                SpinKitRipple(
                  borderWidth: 100,
                  duration: const Duration(milliseconds: 1500),
                  size: Get.width / 1.1,
                  itemBuilder: (BuildContext context, int index) {
                    return CircleAvatar(
                      backgroundColor: ColorRes.grey21.withOpacity(0.40),
                    );
                  },
                ),
                SpinKitRipple(
                  borderWidth: 50,
                  duration: const Duration(milliseconds: 1500),
                  size: Get.width / 1.5,
                  itemBuilder: (BuildContext context, int index) {
                    return CircleAvatar(
                      backgroundColor: ColorRes.grey21.withOpacity(0.30),
                    );
                  },
                ),
                Container(
                  height: Get.width / 3,
                  width: Get.width / 3,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage('${ConstRes.aImageBaseUrl}${Get.arguments[0][FirebaseRes.image]}'),
                    ),
                  ),
                ),
              ],
            ))
        : SizedBox(
            width: Get.width / 1.2,
            height: Get.height / 1.6,
            child: CardSwiper(
              // controller: userController,
              initialIndex: 0,
              // duration: 500,
              onSwipe: (
                int previousIndex,
                int? currentIndex,
                CardSwiperDirection direction,
              ) async {
                if (direction == CardSwiperDirection.bottom || direction == CardSwiperDirection.top) {
                  // widget.exploreScreenViewModel.onEyeButtonTap();
                  return false;
                }
                if (direction == CardSwiperDirection.right) {
                  // updateLike(widget.userData?[previousIndex].id);
                  // previousIndexSelected = currentIndex ?? -1;
                }
                if (direction == CardSwiperDirection.right) {
                  // updateLike(widget.userData?[previousIndex].id);
                  // previousIndexSelected = currentIndex ?? -1;
                  previousIndexSelected = currentIndex ?? -1;

                  final item = widget.userData?.likedprofile;
                  if (item != null && item.toString().split(",").contains(users?.id.toString())) {
                    await showMutualLikeUI(widget.userData!);
                  }
                  updateLike(widget.userData?.id);
                  // return true;
                }
                previousIndexSelected = currentIndex ?? -1;
                widget.model.onNextTap();
                cIndex = 1;
                setState(() {});
                return true;
              },
              onSwipeDirectionChange: (
                CardSwiperDirection horizontalDirection,
                CardSwiperDirection verticalDirection,
              ) {
                if (kDebugMode) {
                  print("horizontalDirection.....     $horizontalDirection");
                }

                if (currentDirection != horizontalDirection) {
                  currentDirection = horizontalDirection;
                  setState(() {});
                }
              },
              allowedSwipeDirection: const AllowedSwipeDirection.only(left: true, right: true),
              backCardOffset: Offset.zero,
              cardsCount: 2,
              cardBuilder: (BuildContext context, int currentProfileIndex, int horizontalOffsetPercentage,
                  int verticalOffsetPercentage) {
                print("currentProfileIndex....   ${currentProfileIndex}");
                if (cIndex == 1 || currentProfileIndex == 1) return const SizedBox.shrink();
                return SizedBox(
                  width: Get.width / 1.2,
                  height: Get.height / 1.6,
                  child: Stack(
                    children: [
                      (widget.userData?.images == null || widget.userData!.images!.isEmpty)
                          ? Stack(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: ColorRes.darkOrange.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(20),
                                  ),
                                ),
                                Center(
                                  child: Container(
                                    width: Get.width - 100,
                                    height: Get.height - 256,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle, color: ColorRes.darkOrange.withOpacity(0.2)),
                                    child: Image.asset(
                                      AssetRes.themeLabel,
                                    ),
                                  ),
                                ),
                              ],
                            )
                          : ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: PageView.builder(
                                controller: widget.pageController,
                                itemCount: widget.userData?.images?.length,
                                physics: const NeverScrollableScrollPhysics(),
                                itemBuilder: (context, index) {
                                  String? profileImage = widget.userData?.images?[index].image;
                                  return FractionallySizedBox(
                                    widthFactor: 1 / widget.pageController.viewportFraction,
                                    child: Stack(
                                      children: [
                                        CachedNetworkImage(
                                          imageUrl: '${ConstRes.aImageBaseUrl}$profileImage',
                                          cacheKey: '${ConstRes.aImageBaseUrl}$profileImage',
                                          fit: BoxFit.cover,
                                          width: Get.width,
                                          height: Get.height - 256,
                                          filterQuality: FilterQuality.medium,
                                          errorWidget: (context, error, stackTrace) {
                                            return Container(
                                              color: ColorRes.grey13,
                                              child: Image.asset(
                                                AssetRes.themeLabel,
                                                width: Get.width,
                                                height: Get.height - 256,
                                              ),
                                            );
                                          },
                                          progressIndicatorBuilder: (context, child, loadingProgress) {
                                            return ShimmerScreen.rectangular(
                                              width: Get.width,
                                              height: Get.height - 256,
                                              shapeBorder: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(21),
                                              ),
                                            );
                                          },
                                        ),
                                        Row(
                                          children: [
                                            Expanded(
                                              child: InkWell(
                                                onTap: widget.model.onLeftBtnClick,
                                                child: Container(
                                                  height: Get.height - 256,
                                                  color: ColorRes.transparent,
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child: InkWell(
                                                onTap: widget.onRightBtnClick,
                                                child: Container(
                                                  height: Get.height - 256,
                                                  color: ColorRes.transparent,
                                                ),
                                              ),
                                            ),
                                          ],
                                        )
                                      ],
                                    ),
                                  );
                                },
                              ),
                            ),
                      SizedBox(
                        height: Get.height - 256,
                        width: Get.width,
                        child: Column(
                          children: [
                            const SizedBox(height: 14),
                            TopStoryLine(pageController: widget.pageController, images: widget.userData?.images ?? []),
                            const Spacer(),
                            Padding(
                              padding: const EdgeInsets.only(left: 9),
                              child: Row(
                                children: [
                                  SocialIcon(
                                      icon: AssetRes.instagramLogo,
                                      size: 15,
                                      onSocialIconTap: widget.onInstagramTap,
                                      isVisible: widget.isSocialBtnVisible(widget.userData?.instagram)),
                                  SocialIcon(
                                      icon: AssetRes.facebookLogo,
                                      size: 21.0,
                                      onSocialIconTap: widget.onFacebookTap,
                                      isVisible: widget.isSocialBtnVisible(widget.userData?.facebook)),
                                  SocialIcon(
                                      icon: AssetRes.youtubeLogo,
                                      size: 20.16,
                                      onSocialIconTap: widget.onYoutubeTap,
                                      isVisible: widget.isSocialBtnVisible(widget.userData?.youtube)),
                                  const Spacer(),
                                  Visibility(
                                    visible: widget.userData?.isLiveNow == 0 ? false : true,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: BackdropFilter(
                                        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                                        child: InkWell(
                                          onTap: widget.onLiveBtnTap,
                                          child: Container(
                                            height: 35,
                                            width: 113,
                                            padding: const EdgeInsets.all(4),
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(40),
                                              color: ColorRes.black.withOpacity(0.33),
                                            ),
                                            child: Row(
                                              children: [
                                                const LiveIcon(),
                                                Text(
                                                  " ${S.current.liveCap}",
                                                  style: const TextStyle(
                                                    color: ColorRes.white,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                                Text(
                                                  " ${S.current.nowCap}",
                                                  style: const TextStyle(
                                                    color: ColorRes.white,
                                                    fontFamily: FontRes.bold,
                                                    fontSize: 12,
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                ],
                              ),
                            ),
                            ProfileDetailCard(
                              onImageTap: widget.model.onImageTap,
                              userData: widget.userData,
                            )
                          ],
                        ),
                      ),
                      if (previousIndexSelected == currentProfileIndex && currentDirection == CardSwiperDirection.right)
                        Positioned(
                            top: 0,
                            left: -context.width * .38,
                            // bottom: 0,
                            // right: 0,
                            child: Container(
                              // height: context.height*.5,
                              width: context.width * 1.1,
                              alignment: Alignment.centerLeft,
                              child: ColorFiltered(
                                colorFilter: const ColorFilter.mode(
                                  Colors.pink,
                                  BlendMode.modulate,
                                ),
                                child: Lottie.asset(
                                  "assets/icons/love_animation.json",
                                  filterQuality: FilterQuality.high,
                                ),
                              ),
                            ).animate().fade(duration: GetNumUtils(500).milliseconds)),
                      if (previousIndexSelected == currentProfileIndex && currentDirection == CardSwiperDirection.left)
                        Positioned(
                            top: 0,
                            right: 0,
                            // bottom: 0,
                            // right: 0,
                            child: Container(
                              // height: context.height*.5,
                              width: context.width * .36,
                              alignment: Alignment.centerLeft,
                              // height: ,
                              child: ColorFiltered(
                                colorFilter: const ColorFilter.mode(
                                  Colors.pink,
                                  BlendMode.modulate,
                                ),
                                child: Image.asset(Assets.iconsNope),
                              ),
                            )
                                .animate()
                                .fade(duration: GetNumUtils(500).milliseconds)
                                .scale(duration: GetNumUtils(100).milliseconds)),
                    ],
                  ),
                );
              },
            ),
          );
  }
}
