class FontRes {
  static const String regular = 'gilroy';
  static const String bold = 'gilroy_bold';
  static const String extraBold = 'gilroy_extra_bold';
  static const String heavy = 'gilroy_heavy';
  static const String light = 'gilroy_light';
  static const String medium = 'gilroy_medium';
  static const String semiBold = 'gilroy_semibold';
}
