class ConstRes {
  ///------------------------ Backend urls and key ------------------------///

  static const String base = 'https://admin902.pinesocial.ca/';
  static const String aBaseUrl = '${base}api/';
  static const String aImageBaseUrl = '${base}public/storage/';
  static const String apiKey = '123';

  ///------------------------ Firebase FCM token And Token Id ------------------------///

  static const String subscribeToTopic = 'Pine';

  ///------------------------ Agora app Id ------------------------///
  static const String agoraAppId = "20f5a1d88c9b4dd191c94d64b86557b4";
  static const String customerId = "07af79878ffd42c794a97119471eafb0";
  static const String customerSecret = "fb021f035aae4f25b960530522bce533";
}

///_____________________________ Image Quality _______________________///
const double maxWidth = 720;
const double maxHeight = 720;
const int quality = 100;
