package com.retrytech.orange_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity() {
}
